import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { QuickView } from './components/QuickView';
import { SectionHeader } from './components/SectionHeader';
import { ContactForm } from './components/ContactForm';
import { Footer } from './components/Footer';
import { PRODUCTS, REVIEWS, INSTAGRAM_POSTS } from './constants';
import { Product } from './types';
import { Star, ArrowRight, Instagram, Heart } from 'lucide-react';

export default function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const featuredProducts = PRODUCTS.filter(p => p.isFeatured);
  const menProducts = PRODUCTS.filter(p => p.category === 'Men');
  const newArrivals = PRODUCTS.filter(p => p.isNew);

  return (
    <div className="min-h-screen bg-black overflow-x-hidden">
      <Navbar />
      
      <main>
        {/* Hero Section */}
        <Hero />

        {/* Featured Collection */}
        <section id="collections" className="py-32 px-6 max-w-7xl mx-auto">
          <SectionHeader 
            title="The Silver Lining" 
            subtitle="Featured Collection" 
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {featuredProducts.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onQuickView={setSelectedProduct} 
              />
            ))}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col items-center justify-center p-12 border border-white/10 bg-white/5 space-y-8 text-center"
            >
              <h3 className="text-3xl font-serif italic">Discover the full <br />Winter MMXXV Collection</h3>
              <button className="flex items-center gap-3 text-xs uppercase tracking-[0.3em] font-bold hover:gap-6 transition-all duration-500">
                View All <ArrowRight size={16} />
              </button>
            </motion.div>
          </div>
        </section>

        {/* Categories Section */}
        <section className="h-[80vh]">
          <div id="men" className="relative group h-full overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1488161628813-04466f872be2?q=80&w=1000&auto=format&fit=crop" 
              alt="Men's Collection"
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 opacity-70"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-center p-12">
              <span className="text-[10px] uppercase tracking-[0.5em] mb-4">Sophistication</span>
              <h2 className="text-6xl md:text-7xl font-serif mb-8">Men's</h2>
              <button className="px-12 py-4 border border-white text-[10px] uppercase tracking-[0.3em] font-bold hover:bg-white hover:text-black transition-all duration-500">
                Explore
              </button>
            </div>
          </div>
        </section>

        {/* New Arrivals */}
        <section id="new-arrivals" className="py-32 bg-neutral-950">
          <div className="max-w-7xl mx-auto px-6">
            <SectionHeader 
              title="Freshly Crafted" 
              subtitle="New Arrivals" 
              align="left"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {newArrivals.map((product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onQuickView={setSelectedProduct} 
                />
              ))}
            </div>
          </div>
        </section>

        {/* About Brand */}
        <section id="about" className="py-40 px-6 overflow-hidden">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative aspect-[4/5]"
            >
              <img 
                src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=1000&auto=format&fit=crop" 
                alt="Brand Story"
                className="w-full h-full object-cover grayscale"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-white/5 backdrop-blur-xl border border-white/10 p-8 hidden md:flex flex-col justify-center">
                <span className="text-4xl font-serif italic mb-2">15+</span>
                <p className="text-[10px] uppercase tracking-widest text-white/40">Years of Craftsmanship in Paris</p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-12"
            >
              <SectionHeader 
                title="The Metallic Philosophy" 
                subtitle="Our Story" 
                align="left"
                className="mb-0"
              />
              <p className="text-xl font-serif italic text-white/80 leading-relaxed">
                "We don't just create clothes; we forge identities. Our mission is to blend the cold precision of metallic aesthetics with the warm soul of haute couture."
              </p>
              <div className="space-y-6 text-white/40 leading-relaxed font-light">
                <p>
                  Founded in the heart of Paris, Metallic Fashion House began as a small atelier dedicated to exploring unconventional materials in luxury fashion. Today, we are a global symbol of modern elegance, known for our signature silver-thread weaves and minimalist silhouettes.
                </p>
                <p>
                  Every piece is a testament to our commitment to sustainability and ethical craftsmanship. We work exclusively with family-owned mills that share our vision for a more conscious luxury future.
                </p>
              </div>
              <button className="text-xs uppercase tracking-[0.4em] font-bold luxury-underline pb-2">
                Discover Our Atelier
              </button>
            </motion.div>
          </div>
        </section>

        {/* Customer Reviews */}
        <section className="py-32 bg-white text-black">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-24">
              <span className="text-[10px] uppercase tracking-[0.5em] text-black/40 block mb-4">Voices of Elegance</span>
              <h2 className="text-5xl md:text-7xl font-serif">Client Testimonials</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
              {REVIEWS.map((review) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="flex flex-col items-center text-center space-y-6"
                >
                  <div className="flex gap-1">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} size={14} fill="black" />
                    ))}
                  </div>
                  <p className="text-lg font-serif italic leading-relaxed">"{review.comment}"</p>
                  <div>
                    <h4 className="text-xs uppercase tracking-widest font-bold">{review.author}</h4>
                    <span className="text-[10px] text-black/40">{review.date}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Instagram Gallery */}
        <section className="py-32">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
              <SectionHeader 
                title="Seen on Social" 
                subtitle="Instagram" 
                align="left"
                className="mb-0"
              />
              <a href="#" className="flex items-center gap-3 text-xs uppercase tracking-[0.3em] font-bold hover:text-white/60 transition-colors">
                @metallic_house <Instagram size={16} />
              </a>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {INSTAGRAM_POSTS.map((post) => (
                <motion.div
                  key={post.id}
                  whileHover={{ y: -10 }}
                  className="relative group aspect-square overflow-hidden"
                >
                  <img 
                    src={post.image} 
                    alt="Instagram Post"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="flex items-center gap-2">
                      <Heart size={16} fill="white" />
                      <span className="text-xs font-bold">{post.likes}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-32 px-6 bg-neutral-950">
          <div className="max-w-7xl mx-auto">
            <ContactForm />
          </div>
        </section>
      </main>

      <Footer />

      {/* Quick View Modal */}
      <QuickView 
        product={selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
      />
    </div>
  );
}
