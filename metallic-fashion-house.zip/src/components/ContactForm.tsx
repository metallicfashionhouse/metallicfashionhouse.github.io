import React from 'react';
import { motion } from 'motion/react';
import { Send } from 'lucide-react';

export const ContactForm = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        className="space-y-8"
      >
        <h3 className="text-5xl font-serif leading-tight">Get in Touch with <br />Our Concierge</h3>
        <p className="text-white/40 leading-relaxed font-light">
          Whether you have a question about our collections, need styling advice, or require assistance with an order, our dedicated team is here to provide a seamless luxury experience.
        </p>
        
        <div className="space-y-6 pt-8">
          <div>
            <span className="text-[10px] uppercase tracking-widest text-white/40 block mb-2">Email</span>
            <a href="mailto:concierge@metallic.com" className="text-xl font-serif hover:text-white/60 transition-colors">concierge@metallic.com</a>
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-widest text-white/40 block mb-2">Phone</span>
            <a href="tel:+1234567890" className="text-xl font-serif hover:text-white/60 transition-colors">+1 (234) 567-890</a>
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-widest text-white/40 block mb-2">Boutique</span>
            <p className="text-xl font-serif">123 Avenue Montaigne, Paris, France</p>
          </div>
        </div>
      </motion.div>

      <motion.form
        initial={{ opacity: 0, x: 30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        className="glass p-12 space-y-8"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] uppercase tracking-widest text-white/40">Full Name</label>
            <input
              type="text"
              className="w-full bg-transparent border-b border-white/10 py-3 focus:border-white outline-none transition-colors"
              placeholder="John Doe"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] uppercase tracking-widest text-white/40">Email Address</label>
            <input
              type="email"
              className="w-full bg-transparent border-b border-white/10 py-3 focus:border-white outline-none transition-colors"
              placeholder="john@example.com"
            />
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-[10px] uppercase tracking-widest text-white/40">Subject</label>
          <select className="w-full bg-transparent border-b border-white/10 py-3 focus:border-white outline-none transition-colors appearance-none">
            <option className="bg-black">General Inquiry</option>
            <option className="bg-black">Order Status</option>
            <option className="bg-black">Styling Advice</option>
            <option className="bg-black">Press & Media</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-[10px] uppercase tracking-widest text-white/40">Message</label>
          <textarea
            rows={4}
            className="w-full bg-transparent border-b border-white/10 py-3 focus:border-white outline-none transition-colors resize-none"
            placeholder="How can we assist you?"
          />
        </div>
        <button className="w-full py-5 bg-white text-black uppercase tracking-[0.3em] text-[10px] font-bold hover:bg-metallic-silver transition-all duration-500 flex items-center justify-center gap-3">
          <Send size={16} />
          Send Message
        </button>
      </motion.form>
    </div>
  );
};
