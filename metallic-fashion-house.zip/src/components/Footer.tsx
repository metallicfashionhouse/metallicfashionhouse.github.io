import React from 'react';
import { motion } from 'motion/react';
import { Instagram, Facebook, Twitter, Youtube } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-neutral-950 pt-24 pb-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
          {/* Brand Info */}
          <div className="space-y-8">
            <div className="flex flex-col">
              <span className="text-2xl font-serif tracking-[0.15em] uppercase font-light">
                Metallic
              </span>
              <span className="text-[8px] tracking-[0.5em] uppercase font-display opacity-60 -mt-1">
                Fashion House
              </span>
            </div>
            <p className="text-white/40 text-sm leading-relaxed max-w-xs">
              Redefining luxury through the lens of modern minimalism and metallic sophistication. Crafted for the bold, the elegant, and the timeless.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-white/40 hover:text-white transition-colors"><Instagram size={20} strokeWidth={1.5} /></a>
              <a href="#" className="text-white/40 hover:text-white transition-colors"><Facebook size={20} strokeWidth={1.5} /></a>
              <a href="#" className="text-white/40 hover:text-white transition-colors"><Twitter size={20} strokeWidth={1.5} /></a>
              <a href="#" className="text-white/40 hover:text-white transition-colors"><Youtube size={20} strokeWidth={1.5} /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-[10px] uppercase tracking-[0.3em] font-display text-white mb-8">Collections</h4>
            <ul className="space-y-4">
              {['Men', 'Accessories', 'New Arrivals', 'Limited Edition'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-white/40 hover:text-white text-sm transition-colors luxury-underline">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-[10px] uppercase tracking-[0.3em] font-display text-white mb-8">Support</h4>
            <ul className="space-y-4">
              {['Contact Us', 'Shipping & Returns', 'Size Guide', 'Privacy Policy', 'Terms of Service'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-white/40 hover:text-white text-sm transition-colors luxury-underline">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-[10px] uppercase tracking-[0.3em] font-display text-white mb-8">Newsletter</h4>
            <p className="text-white/40 text-sm mb-6">Join our exclusive circle for early access to new collections and private events.</p>
            <form className="relative">
              <input
                type="email"
                placeholder="Email Address"
                className="w-full bg-transparent border-b border-white/20 py-3 text-sm focus:border-white outline-none transition-colors pr-12"
              />
              <button className="absolute right-0 top-1/2 -translate-y-1/2 text-[10px] uppercase tracking-widest font-bold hover:text-metallic-silver transition-colors">
                Join
              </button>
            </form>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[10px] uppercase tracking-widest text-white/20">
            &copy; 2025 Metallic Fashion House. All Rights Reserved.
          </p>
          <div className="flex space-x-8">
            <span className="text-[10px] uppercase tracking-widest text-white/20">Paris</span>
            <span className="text-[10px] uppercase tracking-widest text-white/20">London</span>
            <span className="text-[10px] uppercase tracking-widest text-white/20">New York</span>
            <span className="text-[10px] uppercase tracking-widest text-white/20">Tokyo</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
