import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, Menu, X, Search, User } from 'lucide-react';

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Collections', href: '#collections' },
    { name: 'Men', href: '#men' },
    { name: 'New Arrivals', href: '#new-arrivals' },
    { name: 'About', href: '#about' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled ? 'py-4 glass' : 'py-8 bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Mobile Menu Toggle */}
        <button
          className="lg:hidden text-white"
          onClick={() => setIsMobileMenuOpen(true)}
        >
          <Menu size={24} />
        </button>

        {/* Desktop Links - Left */}
        <div className="hidden lg:flex items-center space-x-8">
          {navLinks.slice(0, 3).map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-xs uppercase tracking-[0.2em] font-display hover:text-white/60 transition-colors luxury-underline"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Logo */}
        <a href="/" className="flex flex-col items-center">
          <span className="text-2xl md:text-3xl font-serif tracking-[0.15em] uppercase font-light">
            Metallic
          </span>
          <span className="text-[8px] md:text-[10px] tracking-[0.5em] uppercase font-display opacity-60 -mt-1">
            Fashion House
          </span>
        </a>

        {/* Desktop Links - Right */}
        <div className="hidden lg:flex items-center space-x-8">
          {navLinks.slice(3).map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-xs uppercase tracking-[0.2em] font-display hover:text-white/60 transition-colors luxury-underline"
            >
              {link.name}
            </a>
          ))}
          <div className="flex items-center space-x-6 ml-4">
            <button className="hover:text-white/60 transition-colors">
              <Search size={18} strokeWidth={1.5} />
            </button>
            <button className="hover:text-white/60 transition-colors">
              <User size={18} strokeWidth={1.5} />
            </button>
            <button className="hover:text-white/60 transition-colors relative">
              <ShoppingBag size={18} strokeWidth={1.5} />
              <span className="absolute -top-1 -right-1 bg-white text-black text-[8px] w-3 h-3 rounded-full flex items-center justify-center font-bold">
                0
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Icons */}
        <div className="lg:hidden flex items-center space-x-4">
          <button className="hover:text-white/60 transition-colors">
            <ShoppingBag size={20} strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '-100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '-100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-black p-8 flex flex-col"
          >
            <div className="flex justify-end">
              <button onClick={() => setIsMobileMenuOpen(false)}>
                <X size={32} strokeWidth={1} />
              </button>
            </div>
            <div className="flex flex-col space-y-8 mt-12">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-4xl font-serif italic tracking-wide"
                >
                  {link.name}
                </a>
              ))}
            </div>
            <div className="mt-auto pt-8 border-t border-white/10 flex flex-col space-y-4">
              <a href="#" className="text-sm uppercase tracking-widest opacity-60">Account</a>
              <a href="#" className="text-sm uppercase tracking-widest opacity-60">Search</a>
              <a href="#" className="text-sm uppercase tracking-widest opacity-60">Contact</a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
