import React from 'react';
import { motion } from 'motion/react';
import { Eye, ShoppingCart } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group relative"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-neutral-900">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        
        {/* Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {product.isNew && (
            <span className="bg-white text-black text-[10px] uppercase tracking-widest px-3 py-1 font-bold">
              New
            </span>
          )}
          {product.isFeatured && (
            <span className="bg-black/50 backdrop-blur-sm text-white text-[10px] uppercase tracking-widest px-3 py-1 border border-white/20">
              Limited
            </span>
          )}
        </div>

        {/* Overlay Actions */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center gap-4">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => onQuickView(product)}
            className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-xl"
          >
            <Eye size={20} />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="w-12 h-12 rounded-full bg-black text-white flex items-center justify-center shadow-xl border border-white/20"
          >
            <ShoppingCart size={20} />
          </motion.button>
        </div>
      </div>

      <div className="mt-4 flex justify-between items-start">
        <div>
          <h3 className="text-sm font-display uppercase tracking-wider text-white/80 group-hover:text-white transition-colors">
            {product.name}
          </h3>
          <p className="text-xs text-white/40 mt-1 italic font-serif">
            {product.category}
          </p>
        </div>
        <p className="text-sm font-medium tracking-tighter">
          ${product.price.toLocaleString()}
        </p>
      </div>
    </motion.div>
  );
};
