import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingBag, Heart, Share2 } from 'lucide-react';
import { Product } from '../types';

interface QuickViewProps {
  product: Product | null;
  onClose: () => void;
}

export const QuickView: React.FC<QuickViewProps> = ({ product, onClose }) => {
  if (!product) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/90 backdrop-blur-sm"
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-5xl bg-neutral-950 border border-white/10 overflow-hidden flex flex-col md:flex-row"
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            <X size={24} />
          </button>

          {/* Image Section */}
          <div className="w-full md:w-1/2 aspect-square md:aspect-auto overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Details Section */}
          <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col">
            <div className="mb-auto">
              <span className="text-xs uppercase tracking-[0.3em] text-white/40 font-display">
                {product.category}
              </span>
              <h2 className="text-4xl md:text-5xl font-serif mt-4 mb-6 leading-tight">
                {product.name}
              </h2>
              <p className="text-2xl font-light tracking-tighter mb-8">
                ${product.price.toLocaleString()}
              </p>
              <p className="text-white/60 leading-relaxed mb-8 font-sans font-light">
                {product.description}
              </p>

              <div className="space-y-6">
                <div>
                  <span className="text-[10px] uppercase tracking-widest text-white/40 block mb-3">Select Size</span>
                  <div className="flex gap-3">
                    {['XS', 'S', 'M', 'L', 'XL'].map((size) => (
                      <button
                        key={size}
                        className="w-12 h-12 border border-white/10 flex items-center justify-center text-xs hover:border-white hover:bg-white hover:text-black transition-all duration-300"
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 space-y-4">
              <button className="w-full py-5 bg-white text-black uppercase tracking-[0.2em] text-xs font-bold hover:bg-metallic-silver transition-colors flex items-center justify-center gap-3">
                <ShoppingBag size={18} />
                Add to Bag
              </button>
              <div className="flex gap-4">
                <button className="flex-1 py-4 border border-white/10 uppercase tracking-[0.2em] text-[10px] hover:bg-white/5 transition-colors flex items-center justify-center gap-2">
                  <Heart size={14} />
                  Wishlist
                </button>
                <button className="flex-1 py-4 border border-white/10 uppercase tracking-[0.2em] text-[10px] hover:bg-white/5 transition-colors flex items-center justify-center gap-2">
                  <Share2 size={14} />
                  Share
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
