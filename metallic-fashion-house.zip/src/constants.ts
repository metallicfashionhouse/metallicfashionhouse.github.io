import { Product, Review, InstagramPost } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Metallic Silk Evening Gown',
    price: 1250,
    category: 'Women',
    image: 'https://images.unsplash.com/photo-1539109132382-381bb3f1c2b3?q=80&w=1000&auto=format&fit=crop',
    description: 'A stunning floor-length gown crafted from premium metallic silk, featuring a sophisticated draped silhouette.',
    isFeatured: true,
    isNew: true,
  },
  {
    id: '2',
    name: 'Silver Thread Tailored Blazer',
    price: 850,
    category: 'Men',
    image: 'https://images.unsplash.com/photo-1594932224456-806736fdfd83?q=80&w=1000&auto=format&fit=crop',
    description: 'Expertly tailored blazer with subtle silver thread detailing, perfect for high-end evening events.',
    isFeatured: true,
  },
  {
    id: '3',
    name: 'Obsidian Leather Trench',
    price: 1500,
    category: 'Women',
    image: 'https://images.unsplash.com/photo-1539008835279-434674508233?q=80&w=1000&auto=format&fit=crop',
    description: 'Premium Italian leather trench coat in deep obsidian black with metallic hardware accents.',
    isNew: true,
  },
  {
    id: '4',
    name: 'Chrome Accent Dress Shirt',
    price: 320,
    category: 'Men',
    image: 'https://images.unsplash.com/photo-1621072156002-e2fcced0b170?q=80&w=1000&auto=format&fit=crop',
    description: 'Crisp white cotton shirt featuring unique chrome-finished buttons and minimalist collar.',
  },
  {
    id: '5',
    name: 'Liquid Silver Slip Dress',
    price: 580,
    category: 'Women',
    image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?q=80&w=1000&auto=format&fit=crop',
    description: 'Minimalist slip dress with a liquid-like silver finish that catches the light beautifully.',
  },
  {
    id: '6',
    name: 'Brushed Steel Cufflinks',
    price: 180,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=1000&auto=format&fit=crop',
    description: 'Hand-crafted cufflinks made from premium brushed steel with geometric precision.',
  },
  {
    id: '7',
    name: 'Midnight Velvet Tuxedo',
    price: 2100,
    category: 'Men',
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1000&auto=format&fit=crop',
    description: 'Luxurious midnight blue velvet tuxedo with silk lapels and metallic lining.',
    isNew: true,
  },
  {
    id: '8',
    name: 'Platinum Pleated Skirt',
    price: 450,
    category: 'Women',
    image: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?q=80&w=1000&auto=format&fit=crop',
    description: 'Elegant pleated skirt with a high-shine platinum finish and fluid movement.',
  }
];

export const REVIEWS: Review[] = [
  {
    id: '1',
    author: 'Alexandra V.',
    rating: 5,
    comment: 'The quality of the metallic silk is unlike anything I have ever worn. Truly a masterpiece of modern fashion.',
    date: 'Oct 12, 2025',
  },
  {
    id: '2',
    author: 'Julian M.',
    rating: 5,
    comment: 'Metallic Fashion House has redefined luxury for me. The tailoring on the blazer is impeccable.',
    date: 'Nov 05, 2025',
  },
  {
    id: '3',
    author: 'Elena R.',
    rating: 4,
    comment: 'Stunning designs and fast international shipping. The packaging itself felt like a luxury experience.',
    date: 'Dec 20, 2025',
  }
];

export const INSTAGRAM_POSTS: InstagramPost[] = [
  { id: '1', image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=600&auto=format&fit=crop', likes: '1.2k' },
  { id: '2', image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=600&auto=format&fit=crop', likes: '2.5k' },
  { id: '3', image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=600&auto=format&fit=crop', likes: '3.1k' },
  { id: '4', image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=600&auto=format&fit=crop', likes: '1.8k' },
];
