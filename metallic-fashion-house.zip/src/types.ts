export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'Men' | 'Women' | 'Accessories';
  image: string;
  description: string;
  isNew?: boolean;
  isFeatured?: boolean;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
}

export interface InstagramPost {
  id: string;
  image: string;
  likes: string;
}
